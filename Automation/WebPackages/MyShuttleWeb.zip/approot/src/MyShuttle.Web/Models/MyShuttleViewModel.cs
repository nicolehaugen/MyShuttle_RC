﻿

namespace MyShuttle.Web.Models
{
    public class MyShuttleViewModel
    {
        public string MainMessage { get; set; }
    }
}