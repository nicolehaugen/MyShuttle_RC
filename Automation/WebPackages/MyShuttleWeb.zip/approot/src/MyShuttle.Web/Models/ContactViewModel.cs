namespace MyShuttle.Web.Models
{
    using System.ComponentModel.DataAnnotations;

    public class ContactViewModel
    {

        public string Name { get; set; }

        public string Email { get; set; }

        public string Message { get; set; }
    }
}