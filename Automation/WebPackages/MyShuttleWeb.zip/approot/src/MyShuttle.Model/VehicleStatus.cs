﻿namespace MyShuttle.Model
{
    public enum VehicleStatus
    {
        Unknown = 0,
        Occupied = 1,
        Free = 2,
    }
}