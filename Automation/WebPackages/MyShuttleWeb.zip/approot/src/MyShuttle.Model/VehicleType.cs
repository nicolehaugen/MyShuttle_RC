﻿namespace MyShuttle.Model
{
    public enum VehicleType
    {
        Unknown = 0,
        Van = 1,
        Minivan = 2,
        Luxury = 3,
        Compact = 4,
        Intermediate = 5,
        Premium = 6,
        FullSize = 7
    }
}