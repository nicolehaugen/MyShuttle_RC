﻿namespace MyShuttle.API
{
    public static class GlobalConfig
    {
        public const int TOP_NUMBER = 5;
    }
}