bower-signalr
=============

Bower package for the SignalR JavaScript client. Source code is in the main repo at https://github.com/SignalR/SignalR, please log issues there.
